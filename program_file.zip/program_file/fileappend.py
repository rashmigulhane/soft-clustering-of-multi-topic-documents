from nltk.corpus.reader.plaintext import PlaintextCorpusReader
import os
from nltk.tokenize import RegexpTokenizer
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import nltk.data
corpusdir = '/home/abc/Desktop/rash_adm/original_dataset/A/A00'
newcorpus = PlaintextCorpusReader(corpusdir,'.*')
val=1001
sortedall = sorted(newcorpus.fileids())
pointer = 'True'

i=0
t=1000
print len(sortedall)
while i<len(sortedall):
	pointer = 'True'
	empty = []
	
	while pointer == 'True' and i<len(sortedall):
	    filename = sortedall[i]
	    #print filename
	    filename_sub = filename[4:8]
	    print filename_sub
	    if filename_sub == str(val):
		     i=i+1
		     empty.append(filename)
		     #print filename
	    else:
		     pointer = 'false'
		     print "fail"
	corpusdir_p = '/home/abc/Desktop/rash_adm/new_dataset/'
	newfile = open(corpusdir_p +str(t) + ".txt",'w')
	nameoffile = str(t) + ".txt"
	q=0
	print empty
	while q<len(empty):
		os.system("cat /home/abc/Desktop/rash_adm/original_dataset/A/A00/" + empty[q] + " >> "+corpusdir_p + nameoffile)
		print empty[q]
		q=q+1
	newfile.close()
	if val == 1046:
		val = 2000
	if val == 2043:
		val = 3000
	#if val == 3012:
	#	val = 4000
	#if val == 4017:
	#	val = 5000
	
	val=val+1	
	t=t+1
	
